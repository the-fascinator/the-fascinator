function show(id) {
  var theDIV = document.getElementById(id);
  if (!theDIV) return;
  theDIV.style.display = "";
}
function hide(id) {
  var theDIV = document.getElementById(id);
  if (!theDIV) return;
  theDIV.style.display = "none";
}
function display(thisone) {
  hideTheOthers();
  showTopOfPageLinks(false);
  show(thisone);
  
  // update the location so we can bookmark the page
  window.location.hash = '#' + thisone;
}
function hideTheOthers() {
  var content = document.getElementById('content');
  var divs = content.getElementsByTagName('div');
  for (var i=0; i<divs.length; i++) {
    /* alert(divs[i].id); */
    if (divs[i].id.substr(0,7) == 'program') {
      hide(divs[i].id);
    }
  }
}
function showAll() {
  showTopOfPageLinks(true);
  var content = document.getElementById('content');
  var divs = content.getElementsByTagName('div');
  for (var i=0; i<divs.length; i++) {
    /* alert(divs[i].id); */
    if (divs[i].id.substr(0,7) == 'program') {
      show(divs[i].id);
    }
  }
}
function showTopOfPageLinks(onf) {
  var links = document.getElementsByTagName("a");
  for (var i=0; i<links.length; i++) {
    if (links[i].className != "topofpage") continue;
    links[i].style.display = onf ? "" : "none";
  }
}

// on load, set the visible section based on the hash part of the URL
window.onload = function() {
	if (this.location.hash == '#showall') showAll();
	else if (this.location.hash != '') display(this.location.hash.substr(1));
}
